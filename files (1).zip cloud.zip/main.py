"""
AgriSense - ESP32 Device Firmware (MicroPython)
Reads soil moisture, temperature & humidity every 15 min,
then publishes over MQTT to AWS IoT Core.

Hardware:
  - ESP32 (any variant)
  - Capacitive soil moisture sensor on ADC pin 34
  - DHT22 temperature/humidity sensor on GPIO pin 4
  - (Optional) LoRa module for long-range farms

Flash this file as main.py on your ESP32.
"""

import time
import json
import machine
import ubinascii
import ussl
import umqtt.robust as mqtt
import dht
import network
from machine import ADC, Pin

# ─────────────────────────────────────────────
# CONFIGURATION  — edit before flashing
# ─────────────────────────────────────────────
WIFI_SSID     = "YourWiFiSSID"
WIFI_PASSWORD = "YourWiFiPassword"

DEVICE_ID = "sensor-001"          # Unique per physical sensor
FARM_ID   = "farm-abc"            # Your farm's ID in AgriSense

AWS_IOT_ENDPOINT = "xxxxxxxx-ats.iot.us-east-1.amazonaws.com"
AWS_IOT_PORT     = 8883
MQTT_TOPIC       = f"agrisense/{FARM_ID}/readings"
COMMAND_TOPIC    = f"agrisense/{FARM_ID}/commands"

# Paths to certs stored in ESP32 flash (upload with ampy or mpremote)
CA_CERT    = "/certs/AmazonRootCA1.pem"
DEVICE_CRT = "/certs/device.crt"
DEVICE_KEY = "/certs/device.key"

# Sensor pins
MOISTURE_PIN = 34    # ADC1 channel 6 — soil moisture sensor
DHT_PIN      = 4     # DHT22 data pin

# Intervals
READ_INTERVAL_SEC  = 900   # 15 minutes
PUBLISH_TIMEOUT_MS = 10000

# Moisture ADC calibration (tune to your sensor in air vs water)
ADC_DRY   = 3400   # raw ADC reading in completely dry soil
ADC_WET   = 1200   # raw ADC reading in saturated soil


# ─────────────────────────────────────────────
# HARDWARE INIT
# ─────────────────────────────────────────────

adc = ADC(Pin(MOISTURE_PIN))
adc.atten(ADC.ATTN_11DB)    # 0–3.6 V range

dht_sensor = dht.DHT22(Pin(DHT_PIN))

VALVE_PIN = Pin(26, Pin.OUT)   # GPIO26 → relay → solenoid valve
VALVE_PIN.value(0)             # Ensure valve is OFF at boot


# ─────────────────────────────────────────────
# WIFI
# ─────────────────────────────────────────────

def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print(f"Connecting to {WIFI_SSID}...")
        wlan.connect(WIFI_SSID, WIFI_PASSWORD)
        for _ in range(20):
            if wlan.isconnected():
                break
            time.sleep(1)
    if wlan.isconnected():
        print(f"WiFi connected: {wlan.ifconfig()[0]}")
    else:
        raise RuntimeError("WiFi connection failed — check credentials")
    return wlan


# ─────────────────────────────────────────────
# MQTT CLIENT
# ─────────────────────────────────────────────

def build_mqtt_client():
    client_id = ubinascii.hexlify(machine.unique_id()).decode()
    with open(CA_CERT, "rb")    as f: ca_cert = f.read()
    with open(DEVICE_CRT, "rb") as f: dev_crt = f.read()
    with open(DEVICE_KEY, "rb") as f: dev_key = f.read()

    ssl_params = {
        "cert": dev_crt,
        "key":  dev_key,
        "cadata": ca_cert,
        "server_side": False,
    }

    client = mqtt.MQTTClient(
        client_id   = client_id,
        server      = AWS_IOT_ENDPOINT,
        port        = AWS_IOT_PORT,
        ssl         = True,
        ssl_params  = ssl_params,
        keepalive   = 60,
    )
    client.set_callback(on_command_received)
    client.connect()
    client.subscribe(COMMAND_TOPIC)
    print("MQTT connected and subscribed to", COMMAND_TOPIC)
    return client


# ─────────────────────────────────────────────
# SENSOR READING
# ─────────────────────────────────────────────

def read_moisture_pct() -> float:
    """Average 10 ADC samples and convert to 0–100 % VWC."""
    samples = [adc.read() for _ in range(10)]
    raw = sum(samples) // len(samples)
    # Linear interpolation between dry (0%) and wet (100%)
    pct = (ADC_DRY - raw) / (ADC_DRY - ADC_WET) * 100.0
    return max(0.0, min(100.0, round(pct, 2)))


def read_dht() -> tuple:
    """Returns (temperature_C, humidity_pct) from DHT22."""
    try:
        dht_sensor.measure()
        return dht_sensor.temperature(), dht_sensor.humidity()
    except OSError:
        return None, None


# ─────────────────────────────────────────────
# ACTUATOR
# ─────────────────────────────────────────────

def activate_valve(duration_min: int):
    print(f"Valve ON for {duration_min} minutes")
    VALVE_PIN.value(1)
    time.sleep(duration_min * 60)
    VALVE_PIN.value(0)
    print("Valve OFF")


# ─────────────────────────────────────────────
# MQTT COMMAND CALLBACK
# ─────────────────────────────────────────────

def on_command_received(topic, msg):
    try:
        cmd = json.loads(msg)
        print("Command received:", cmd)
        if cmd.get("action") == "IRRIGATE":
            duration = int(cmd.get("duration_min", 10))
            activate_valve(duration)
    except Exception as e:
        print("Error processing command:", e)


# ─────────────────────────────────────────────
# MAIN LOOP
# ─────────────────────────────────────────────

def main():
    connect_wifi()
    client = build_mqtt_client()

    while True:
        try:
            # Check for incoming commands (non-blocking)
            client.check_msg()

            # Read sensors
            moisture = read_moisture_pct()
            temp, humidity = read_dht()

            payload = {
                "device_id":    DEVICE_ID,
                "farm_id":      FARM_ID,
                "timestamp":    int(time.time()),
                "soil_moisture": moisture,
                "temperature":  temp if temp is not None else 0,
                "humidity":     humidity if humidity is not None else 0,
            }

            msg = json.dumps(payload)
            client.publish(MQTT_TOPIC, msg, qos=1)
            print(f"Published: {msg}")

        except Exception as e:
            print(f"Error in loop: {e} — reconnecting...")
            try:
                client.reconnect()
            except Exception:
                connect_wifi()
                client = build_mqtt_client()

        # Deep sleep to conserve battery (ESP32-specific)
        # Comment out deep sleep if you need to receive commands continuously
        # machine.deepsleep(READ_INTERVAL_SEC * 1000)

        time.sleep(READ_INTERVAL_SEC)


if __name__ == "__main__":
    main()
