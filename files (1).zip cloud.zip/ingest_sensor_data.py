"""
AgriSense - Lambda Function: Sensor Data Ingestion & Processing
Triggered by AWS IoT Core MQTT messages via IoT Rule
"""

import json
import boto3
import os
import logging
from datetime import datetime, timezone
from decimal import Decimal

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS Clients
dynamodb = boto3.resource("dynamodb")
iot_client = boto3.client("iot-data", endpoint_url=os.environ["IOT_ENDPOINT"])
sns_client = boto3.client("sns")

SENSOR_TABLE = os.environ["SENSOR_TABLE"]          # DynamoDB table for time-series data
FARM_TABLE   = os.environ["FARM_TABLE"]            # DynamoDB table for farm/threshold config
ALERT_TOPIC  = os.environ["SNS_ALERT_TOPIC_ARN"]  # SNS topic for farmer alerts

sensor_table = dynamodb.Table(SENSOR_TABLE)
farm_table   = dynamodb.Table(FARM_TABLE)


def lambda_handler(event, context):
    """
    Entry point. IoT Rule passes MQTT payload as `event`.

    Expected MQTT payload:
    {
        "device_id": "sensor-001",
        "farm_id":   "farm-abc",
        "timestamp": 1700000000,
        "soil_moisture": 42.5,   // % volumetric water content
        "temperature":  28.3,    // °C
        "humidity":     65.1     // %
    }
    """
    logger.info(f"Received event: {json.dumps(event)}")

    try:
        # 1. Validate incoming data
        data = validate_payload(event)

        # 2. Persist to time-series store
        store_reading(data)

        # 3. Fetch farm thresholds
        farm_config = get_farm_config(data["farm_id"])

        # 4. Irrigation decision logic
        decision = evaluate_irrigation(data, farm_config)

        # 5. Send actuator command if needed
        if decision["should_irrigate"]:
            send_actuator_command(data["farm_id"], decision)
            notify_farmer(data, farm_config, decision)

        return {"statusCode": 200, "body": "OK", "decision": decision}

    except ValidationError as e:
        logger.warning(f"Validation failed: {e}")
        return {"statusCode": 400, "body": str(e)}
    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        raise


# ──────────────────────────────────────────────
# VALIDATION
# ──────────────────────────────────────────────

class ValidationError(Exception):
    pass

REQUIRED_FIELDS = ["device_id", "farm_id", "soil_moisture", "temperature", "humidity"]
VALID_RANGES = {
    "soil_moisture": (0, 100),
    "temperature":   (-40, 85),
    "humidity":      (0, 100),
}

def validate_payload(payload: dict) -> dict:
    for field in REQUIRED_FIELDS:
        if field not in payload:
            raise ValidationError(f"Missing required field: {field}")

    for field, (low, high) in VALID_RANGES.items():
        val = payload[field]
        if not isinstance(val, (int, float)):
            raise ValidationError(f"{field} must be numeric, got {type(val)}")
        if not (low <= val <= high):
            raise ValidationError(f"{field}={val} out of range [{low}, {high}]")

    payload["timestamp"] = payload.get("timestamp") or int(datetime.now(timezone.utc).timestamp())
    return payload


# ──────────────────────────────────────────────
# STORAGE  (DynamoDB — time-series pattern)
# ──────────────────────────────────────────────

def store_reading(data: dict):
    """
    Partition key: farm_id#device_id
    Sort key:      ISO-8601 timestamp  (enables range queries)
    TTL:           90 days (DynamoDB TTL attribute)
    """
    pk = f"{data['farm_id']}#{data['device_id']}"
    ts = datetime.utcfromtimestamp(data["timestamp"]).isoformat() + "Z"
    ttl = data["timestamp"] + (90 * 24 * 3600)  # 90-day expiry

    sensor_table.put_item(Item={
        "pk":            pk,
        "sk":            ts,
        "farm_id":       data["farm_id"],
        "device_id":     data["device_id"],
        "soil_moisture": Decimal(str(data["soil_moisture"])),
        "temperature":   Decimal(str(data["temperature"])),
        "humidity":      Decimal(str(data["humidity"])),
        "ttl":           ttl,
    })
    logger.info(f"Stored reading for {pk} at {ts}")


# ──────────────────────────────────────────────
# FARM CONFIG
# ──────────────────────────────────────────────

def get_farm_config(farm_id: str) -> dict:
    response = farm_table.get_item(Key={"farm_id": farm_id})
    if "Item" not in response:
        # Safe defaults when no config exists
        logger.warning(f"No config for farm {farm_id} — using defaults")
        return {
            "farm_id":             farm_id,
            "moisture_threshold":  35.0,   # irrigate below 35%
            "max_irrigate_mins":   20,
            "owner_phone":         None,
            "owner_email":         None,
        }
    return response["Item"]


# ──────────────────────────────────────────────
# IRRIGATION DECISION LOGIC
# ──────────────────────────────────────────────

def evaluate_irrigation(data: dict, config: dict) -> dict:
    moisture   = float(data["soil_moisture"])
    threshold  = float(config.get("moisture_threshold", 35.0))
    max_mins   = int(config.get("max_irrigate_mins", 20))

    should_irrigate = moisture < threshold
    urgency = "HIGH" if moisture < (threshold * 0.7) else "NORMAL"

    # Scale irrigation duration proportionally to deficit
    duration_mins = 0
    if should_irrigate:
        deficit_ratio = (threshold - moisture) / threshold
        duration_mins = min(int(max_mins * deficit_ratio) + 5, max_mins)

    return {
        "should_irrigate": should_irrigate,
        "soil_moisture":   moisture,
        "threshold":       threshold,
        "urgency":         urgency,
        "duration_mins":   duration_mins,
    }


# ──────────────────────────────────────────────
# ACTUATOR COMMAND  (IoT Core → device shadow)
# ──────────────────────────────────────────────

def send_actuator_command(farm_id: str, decision: dict):
    topic = f"agrisense/{farm_id}/commands"
    command = {
        "action":       "IRRIGATE",
        "duration_min": decision["duration_mins"],
        "urgency":      decision["urgency"],
        "issued_at":    datetime.utcnow().isoformat() + "Z",
    }
    iot_client.publish(
        topic=topic,
        qos=1,
        payload=json.dumps(command),
    )
    logger.info(f"Sent IRRIGATE command to {topic}: {command}")


# ──────────────────────────────────────────────
# FARMER ALERT  (SNS)
# ──────────────────────────────────────────────

def notify_farmer(data: dict, config: dict, decision: dict):
    message = (
        f"[AgriSense Alert] Farm {data['farm_id']}\n"
        f"Sensor {data['device_id']} reports soil moisture at "
        f"{data['soil_moisture']:.1f}% (threshold: {decision['threshold']}%).\n"
        f"Irrigation activated for {decision['duration_mins']} minutes. "
        f"Urgency: {decision['urgency']}."
    )
    sns_client.publish(
        TopicArn=ALERT_TOPIC,
        Message=message,
        Subject="AgriSense: Irrigation Triggered",
    )
