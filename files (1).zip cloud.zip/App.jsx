import { useState, useEffect, useCallback } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine
} from "recharts";

// ─── CONFIG ──────────────────────────────────────────────────────────────────
// In production, set this to your API Gateway URL
const API_BASE = process.env.REACT_APP_API_URL || "https://your-api-id.execute-api.us-east-1.amazonaws.com/prod";
const FARM_ID  = "farm-abc";   // Replace with real farm ID
const POLL_MS  = 30_000;       // Refresh every 30 s

// ─── STYLES (Tailwind inline because we're single-file) ───────────────────────
const S = {
  app:     "min-h-screen bg-[#0d1a0f] font-mono text-[#c8e6c9]",
  header:  "border-b border-[#1b5e20] px-6 py-4 flex items-center justify-between",
  logo:    "text-[#69f0ae] text-xl font-bold tracking-widest uppercase",
  grid:    "grid grid-cols-1 md:grid-cols-3 gap-4 p-6",
  card:    "bg-[#0f2211] border border-[#2e7d32] rounded-xl p-5",
  label:   "text-[#558b2f] text-xs uppercase tracking-widest mb-1",
  value:   "text-3xl font-bold text-[#69f0ae]",
  unit:    "text-sm text-[#81c784] ml-1",
  badge:   "inline-block px-2 py-0.5 rounded text-xs font-bold uppercase",
  btn:     "mt-2 px-4 py-2 rounded bg-[#1b5e20] hover:bg-[#2e7d32] text-[#c8e6c9] text-sm transition-colors cursor-pointer border border-[#388e3c]",
  chart:   "col-span-1 md:col-span-3 bg-[#0f2211] border border-[#2e7d32] rounded-xl p-5",
  loading: "text-[#558b2f] text-center py-10 animate-pulse",
};

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const fmt = (v, dec = 1) => (v == null ? "--" : Number(v).toFixed(dec));
const tsLabel = iso => {
  const d = new Date(iso);
  return `${d.getHours().toString().padStart(2,"0")}:${d.getMinutes().toString().padStart(2,"0")}`;
};

function moistureColor(pct, threshold) {
  if (pct == null) return "#558b2f";
  if (pct < threshold * 0.7) return "#ef5350";
  if (pct < threshold)       return "#ffa726";
  return "#69f0ae";
}

// ─── API CALLS ────────────────────────────────────────────────────────────────
async function fetchStatus(farmId) {
  const r = await fetch(`${API_BASE}/farms/${farmId}/status`);
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

async function fetchReadings(farmId) {
  const r = await fetch(`${API_BASE}/farms/${farmId}/readings`);
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

async function postManualIrrigate(farmId, mins) {
  const r = await fetch(`${API_BASE}/farms/${farmId}/irrigate`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ duration_mins: mins }),
  });
  return r.json();
}

async function postConfig(farmId, threshold) {
  const r = await fetch(`${API_BASE}/farms/${farmId}/config`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ moisture_threshold: threshold }),
  });
  return r.json();
}

// ─── SUB-COMPONENTS ───────────────────────────────────────────────────────────

function StatusDot({ online }) {
  return (
    <span className={`inline-block w-2 h-2 rounded-full mr-2 ${online ? "bg-[#69f0ae]" : "bg-[#ef5350]"}`} />
  );
}

function MetricCard({ label, value, unit, sub, color }) {
  return (
    <div className={S.card}>
      <p className={S.label}>{label}</p>
      <p className={S.value} style={{ color: color || "#69f0ae" }}>
        {value}<span className={S.unit}>{unit}</span>
      </p>
      {sub && <p className="text-xs text-[#558b2f] mt-1">{sub}</p>}
    </div>
  );
}

function DeviceRow({ device, threshold }) {
  const m = device.latest;
  const mc = moistureColor(m?.soil_moisture, threshold);
  return (
    <div className="flex items-center justify-between py-2 border-b border-[#1b5e20] last:border-0">
      <div className="flex items-center">
        <StatusDot online={device.online} />
        <span className="text-sm">{device.device_id}</span>
      </div>
      <div className="flex gap-6 text-sm">
        <span style={{ color: mc }}>{fmt(m?.soil_moisture)}%</span>
        <span className="text-[#81c784]">{fmt(m?.temperature)}°C</span>
        <span className="text-[#558b2f]">{fmt(m?.humidity)}% RH</span>
        <span className="text-[#37474f] text-xs">{m?.sk ? tsLabel(m.sk) : "--"}</span>
      </div>
    </div>
  );
}

function MoistureChart({ readings, threshold }) {
  const data = [...readings]
    .sort((a, b) => a.sk < b.sk ? -1 : 1)
    .slice(-48)
    .map(r => ({
      time:     tsLabel(r.sk),
      moisture: Number(r.soil_moisture),
      temp:     Number(r.temperature),
    }));

  return (
    <div className={S.chart}>
      <p className={S.label}>Soil Moisture — Last 48 readings</p>
      <ResponsiveContainer width="100%" height={220}>
        <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1b3a1f" />
          <XAxis dataKey="time" tick={{ fill: "#558b2f", fontSize: 10 }} />
          <YAxis domain={[0, 100]} tick={{ fill: "#558b2f", fontSize: 10 }} unit="%" />
          <Tooltip
            contentStyle={{ background: "#0f2211", border: "1px solid #2e7d32", borderRadius: 8 }}
            labelStyle={{ color: "#69f0ae" }}
            itemStyle={{ color: "#c8e6c9" }}
          />
          <ReferenceLine y={threshold} stroke="#ffa726" strokeDasharray="4 4"
            label={{ value: `Threshold ${threshold}%`, fill: "#ffa726", fontSize: 10 }} />
          <Line type="monotone" dataKey="moisture" stroke="#69f0ae" dot={false} strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function ControlPanel({ farmId, threshold, onThresholdChange }) {
  const [mins, setMins]           = useState(10);
  const [newThreshold, setNewT]   = useState(threshold);
  const [message, setMessage]     = useState("");

  const irrigate = async () => {
    const r = await postManualIrrigate(farmId, mins);
    setMessage(r.message || "Command sent");
    setTimeout(() => setMessage(""), 4000);
  };

  const saveThreshold = async () => {
    await postConfig(farmId, newThreshold);
    onThresholdChange(newThreshold);
    setMessage(`Threshold updated to ${newThreshold}%`);
    setTimeout(() => setMessage(""), 4000);
  };

  return (
    <div className={`${S.card} col-span-1 md:col-span-3`}>
      <p className={S.label}>Control Panel</p>
      <div className="flex flex-wrap gap-6 mt-3">
        {/* Manual Irrigate */}
        <div>
          <p className="text-xs text-[#558b2f] mb-1">Manual Irrigation</p>
          <div className="flex items-center gap-2">
            <input
              type="number" min={1} max={60} value={mins}
              onChange={e => setMins(Number(e.target.value))}
              className="w-16 bg-[#0d1a0f] border border-[#2e7d32] rounded px-2 py-1 text-sm text-[#c8e6c9]"
            />
            <span className="text-xs text-[#558b2f]">min</span>
            <button className={S.btn} onClick={irrigate}>Irrigate Now</button>
          </div>
        </div>

        {/* Threshold */}
        <div>
          <p className="text-xs text-[#558b2f] mb-1">Moisture Threshold (%)</p>
          <div className="flex items-center gap-2">
            <input
              type="number" min={5} max={90} value={newThreshold}
              onChange={e => setNewT(Number(e.target.value))}
              className="w-16 bg-[#0d1a0f] border border-[#2e7d32] rounded px-2 py-1 text-sm text-[#c8e6c9]"
            />
            <button className={S.btn} onClick={saveThreshold}>Save</button>
          </div>
        </div>
      </div>
      {message && (
        <p className="mt-3 text-sm text-[#69f0ae] animate-pulse">{message}</p>
      )}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function App() {
  const [status,    setStatus]    = useState(null);
  const [readings,  setReadings]  = useState([]);
  const [threshold, setThreshold] = useState(35);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState(null);
  const [lastSync,  setLastSync]  = useState(null);

  const refresh = useCallback(async () => {
    try {
      const [s, r] = await Promise.all([fetchStatus(FARM_ID), fetchReadings(FARM_ID)]);
      setStatus(s);
      setReadings(r.readings || []);
      setThreshold(s.threshold || 35);
      setLastSync(new Date().toLocaleTimeString());
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, POLL_MS);
    return () => clearInterval(id);
  }, [refresh]);

  // Aggregate latest values across all devices
  const allLatest  = (status?.devices || []).map(d => d.latest).filter(Boolean);
  const avgMoist   = allLatest.length ? allLatest.reduce((s, r) => s + r.soil_moisture, 0) / allLatest.length : null;
  const avgTemp    = allLatest.length ? allLatest.reduce((s, r) => s + r.temperature,   0) / allLatest.length : null;
  const avgHumid   = allLatest.length ? allLatest.reduce((s, r) => s + r.humidity,      0) / allLatest.length : null;
  const onlineCount = (status?.devices || []).filter(d => d.online).length;

  return (
    <div className={S.app}>
      {/* Header */}
      <header className={S.header}>
        <div>
          <span className={S.logo}>🌱 AgriSense</span>
          <span className="ml-3 text-xs text-[#558b2f]">Precision Irrigation Dashboard</span>
        </div>
        <div className="text-right">
          <p className="text-xs text-[#558b2f]">Farm: {FARM_ID}</p>
          {lastSync && <p className="text-xs text-[#37474f]">Last sync: {lastSync}</p>}
        </div>
      </header>

      {loading && <p className={S.loading}>Loading farm data...</p>}
      {error   && <p className="text-[#ef5350] text-center py-4 text-sm">Error: {error}</p>}

      {!loading && (
        <div className={S.grid}>
          {/* KPI Cards */}
          <MetricCard
            label="Avg Soil Moisture" value={fmt(avgMoist)} unit="%"
            sub={`Threshold: ${threshold}%`}
            color={moistureColor(avgMoist, threshold)}
          />
          <MetricCard label="Avg Temperature" value={fmt(avgTemp)} unit="°C" />
          <MetricCard
            label="Devices Online" value={onlineCount} unit={`/ ${status?.devices?.length || 0}`}
            color={onlineCount > 0 ? "#69f0ae" : "#ef5350"}
          />

          {/* Chart */}
          <MoistureChart readings={readings} threshold={threshold} />

          {/* Device list */}
          <div className={`${S.card} col-span-1 md:col-span-3`}>
            <p className={S.label}>Sensor Devices</p>
            <div className="mt-2">
              {(status?.devices || []).map(d => (
                <DeviceRow key={d.device_id} device={d} threshold={threshold} />
              ))}
              {!status?.devices?.length && (
                <p className="text-xs text-[#558b2f]">No devices registered</p>
              )}
            </div>
          </div>

          {/* Controls */}
          <ControlPanel farmId={FARM_ID} threshold={threshold} onThresholdChange={setThreshold} />
        </div>
      )}
    </div>
  );
}
