"""
AgriSense - IoT Sensor Simulator
Simulates N virtual sensors publishing MQTT data to AWS IoT Core.
Use for local dev, integration testing, and load testing up to 10,000 devices.

Usage:
  pip install paho-mqtt boto3
  python simulator.py --farm-id farm-abc --devices 100 --interval 15
"""

import json
import time
import random
import argparse
import threading
import logging
import boto3
from datetime import datetime, timezone
from dataclasses import dataclass, field

import paho.mqtt.client as mqtt
import ssl

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────

@dataclass
class SimConfig:
    farm_id:      str   = "farm-abc"
    num_devices:  int   = 10
    interval_sec: int   = 900      # 15 minutes between readings
    iot_endpoint: str   = ""       # e.g. xxxx.iot.us-east-1.amazonaws.com
    ca_cert:      str   = "certs/AmazonRootCA1.pem"
    device_cert:  str   = "certs/simulator.crt"
    device_key:   str   = "certs/simulator.key"
    use_boto3:    bool  = False    # True → use boto3 IoT Data for simple test


# ──────────────────────────────────────────────
# VIRTUAL SENSOR MODEL
# ──────────────────────────────────────────────

@dataclass
class VirtualSensor:
    device_id:      str
    farm_id:        str
    moisture:       float = field(default_factory=lambda: random.uniform(20, 80))
    temperature:    float = field(default_factory=lambda: random.uniform(18, 35))
    humidity:       float = field(default_factory=lambda: random.uniform(40, 85))

    def step(self):
        """Simulate realistic sensor drift."""
        # Moisture slowly decreases (evaporation) with noise
        self.moisture    = max(0,   min(100, self.moisture    - random.uniform(-2, 5)))
        self.temperature = max(10,  min(50,  self.temperature + random.uniform(-1, 1)))
        self.humidity    = max(20,  min(100, self.humidity    + random.uniform(-2, 2)))

    def reading(self) -> dict:
        return {
            "device_id":    self.device_id,
            "farm_id":      self.farm_id,
            "timestamp":    int(datetime.now(timezone.utc).timestamp()),
            "soil_moisture": round(self.moisture,    2),
            "temperature":   round(self.temperature, 2),
            "humidity":      round(self.humidity,    2),
        }


# ──────────────────────────────────────────────
# MQTT CLIENT SETUP
# ──────────────────────────────────────────────

def build_paho_client(cfg: SimConfig, client_id: str) -> mqtt.Client:
    client = mqtt.Client(client_id=client_id, protocol=mqtt.MQTTv311)
    client.tls_set(
        ca_certs    = cfg.ca_cert,
        certfile    = cfg.device_cert,
        keyfile     = cfg.device_key,
        tls_version = ssl.PROTOCOL_TLSv1_2,
    )
    client.connect(cfg.iot_endpoint, port=8883, keepalive=60)
    client.loop_start()
    return client


# ──────────────────────────────────────────────
# BOTO3 FALLBACK (no certs needed for dev)
# ──────────────────────────────────────────────

_iot_data_client = None

def get_boto3_client(cfg: SimConfig):
    global _iot_data_client
    if _iot_data_client is None:
        _iot_data_client = boto3.client(
            "iot-data",
            endpoint_url=f"https://{cfg.iot_endpoint}",
        )
    return _iot_data_client


def publish_boto3(cfg: SimConfig, topic: str, payload: dict):
    client = get_boto3_client(cfg)
    client.publish(topic=topic, payload=json.dumps(payload), qos=1)


# ──────────────────────────────────────────────
# DEVICE THREAD
# ──────────────────────────────────────────────

def run_device(cfg: SimConfig, sensor: VirtualSensor, stop_event: threading.Event):
    topic = f"agrisense/{sensor.farm_id}/readings"

    if cfg.use_boto3:
        mqtt_client = None
    else:
        mqtt_client = build_paho_client(cfg, client_id=sensor.device_id)

    while not stop_event.is_set():
        sensor.step()
        payload = sensor.reading()

        try:
            if cfg.use_boto3:
                publish_boto3(cfg, topic, payload)
            else:
                mqtt_client.publish(topic, json.dumps(payload), qos=1)

            logger.info(f"[{sensor.device_id}] moisture={payload['soil_moisture']}% "
                        f"temp={payload['temperature']}°C")
        except Exception as e:
            logger.error(f"[{sensor.device_id}] Publish error: {e}")

        stop_event.wait(timeout=cfg.interval_sec)

    if mqtt_client:
        mqtt_client.loop_stop()
        mqtt_client.disconnect()


# ──────────────────────────────────────────────
# STATISTICS REPORTER
# ──────────────────────────────────────────────

class Stats:
    def __init__(self):
        self.published = 0
        self.errors    = 0
        self.lock      = threading.Lock()

    def inc(self, ok=True):
        with self.lock:
            if ok: self.published += 1
            else:  self.errors    += 1

    def report(self):
        with self.lock:
            rate = self.published / max(1, (time.monotonic() - self._start))
            logger.info(f"[STATS] Published={self.published} Errors={self.errors} Rate={rate:.2f} msg/s")

    def start(self):
        self._start = time.monotonic()


# ──────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="AgriSense IoT Sensor Simulator")
    parser.add_argument("--farm-id",   default="farm-abc",  help="Farm ID")
    parser.add_argument("--devices",   type=int, default=10, help="Number of virtual sensors")
    parser.add_argument("--interval",  type=int, default=15, help="Read interval in seconds (not minutes for testing)")
    parser.add_argument("--endpoint",  default="",           help="AWS IoT endpoint hostname")
    parser.add_argument("--boto3",     action="store_true",  help="Use boto3 (no cert files needed)")
    parser.add_argument("--duration",  type=int, default=0,  help="Stop after N seconds (0 = run forever)")
    args = parser.parse_args()

    cfg = SimConfig(
        farm_id      = args.farm_id,
        num_devices  = args.devices,
        interval_sec = args.interval,
        iot_endpoint = args.endpoint,
        use_boto3    = args.boto3,
    )

    sensors = [
        VirtualSensor(device_id=f"sensor-{i:03d}", farm_id=cfg.farm_id)
        for i in range(cfg.num_devices)
    ]

    stop_event = threading.Event()
    threads = []

    logger.info(f"Starting {cfg.num_devices} virtual sensors for farm '{cfg.farm_id}'")
    logger.info(f"Publishing every {cfg.interval_sec}s → {cfg.iot_endpoint or 'stdout (dry run)'}")

    for sensor in sensors:
        t = threading.Thread(target=run_device, args=(cfg, sensor, stop_event), daemon=True)
        t.start()
        threads.append(t)
        time.sleep(0.05)   # Stagger startup to avoid connection burst

    try:
        if args.duration > 0:
            time.sleep(args.duration)
            logger.info("Duration reached — stopping")
            stop_event.set()
        else:
            while True:
                time.sleep(60)
    except KeyboardInterrupt:
        logger.info("Interrupted — shutting down")
        stop_event.set()

    for t in threads:
        t.join(timeout=5)
    logger.info("All simulators stopped")


if __name__ == "__main__":
    main()
