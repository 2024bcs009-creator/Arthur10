"""
AgriSense - Lambda Function: REST API Handler
Sits behind AWS API Gateway — serves the web/mobile dashboard.

Routes:
  GET  /farms/{farm_id}/readings          → recent sensor readings
  GET  /farms/{farm_id}/readings/history  → paginated history
  POST /farms/{farm_id}/config            → update thresholds
  POST /farms/{farm_id}/irrigate          → manual irrigation trigger
  GET  /farms/{farm_id}/status            → latest status per device
"""

import json
import boto3
import os
import logging
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from boto3.dynamodb.conditions import Key

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb   = boto3.resource("dynamodb")
iot_client = boto3.client("iot-data", endpoint_url=os.environ["IOT_ENDPOINT"])

sensor_table = dynamodb.Table(os.environ["SENSOR_TABLE"])
farm_table   = dynamodb.Table(os.environ["FARM_TABLE"])


# ──────────────────────────────────────────────
# ROUTER
# ──────────────────────────────────────────────

def lambda_handler(event, context):
    method   = event.get("httpMethod", "")
    path     = event.get("path", "")
    path_params = event.get("pathParameters") or {}
    farm_id  = path_params.get("farm_id")
    body     = json.loads(event.get("body") or "{}")

    cors_headers = {
        "Access-Control-Allow-Origin":  "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Content-Type": "application/json",
    }

    try:
        if method == "OPTIONS":
            return build_response(200, {}, cors_headers)

        if method == "GET" and path.endswith("/readings"):
            result = get_recent_readings(farm_id)
        elif method == "GET" and path.endswith("/history"):
            qs = event.get("queryStringParameters") or {}
            result = get_history(farm_id, qs)
        elif method == "GET" and path.endswith("/status"):
            result = get_farm_status(farm_id)
        elif method == "POST" and path.endswith("/config"):
            result = update_farm_config(farm_id, body)
        elif method == "POST" and path.endswith("/irrigate"):
            result = manual_irrigate(farm_id, body)
        else:
            return build_response(404, {"error": "Route not found"}, cors_headers)

        return build_response(200, result, cors_headers)

    except ValueError as e:
        return build_response(400, {"error": str(e)}, cors_headers)
    except Exception as e:
        logger.error(f"Error: {e}", exc_info=True)
        return build_response(500, {"error": "Internal server error"}, cors_headers)


# ──────────────────────────────────────────────
# HANDLERS
# ──────────────────────────────────────────────

def get_recent_readings(farm_id: str, hours: int = 24) -> dict:
    """Return all device readings for a farm in the last N hours."""
    since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat() + "Z"

    # NOTE: In production, GSI on farm_id + sk for efficient fan-out queries.
    # This demo queries by the composite PK pattern.
    devices = _list_farm_devices(farm_id)
    readings = []

    for device_id in devices:
        pk = f"{farm_id}#{device_id}"
        resp = sensor_table.query(
            KeyConditionExpression=Key("pk").eq(pk) & Key("sk").gt(since),
            ScanIndexForward=False,
            Limit=100,
        )
        readings.extend([_clean_item(i) for i in resp.get("Items", [])])

    readings.sort(key=lambda x: x["timestamp"], reverse=True)
    return {"farm_id": farm_id, "readings": readings, "count": len(readings)}


def get_history(farm_id: str, qs: dict) -> dict:
    """Paginated history with optional date range."""
    device_id  = qs.get("device_id")
    start_date = qs.get("start")   # ISO-8601
    end_date   = qs.get("end")
    limit      = min(int(qs.get("limit", 200)), 1000)

    if not device_id:
        raise ValueError("device_id query param required for history")

    pk = f"{farm_id}#{device_id}"
    key_cond = Key("pk").eq(pk)

    if start_date and end_date:
        key_cond = key_cond & Key("sk").between(start_date, end_date)
    elif start_date:
        key_cond = key_cond & Key("sk").gte(start_date)

    resp = sensor_table.query(
        KeyConditionExpression=key_cond,
        ScanIndexForward=False,
        Limit=limit,
    )
    return {
        "farm_id":    farm_id,
        "device_id":  device_id,
        "readings":   [_clean_item(i) for i in resp.get("Items", [])],
        "last_key":   resp.get("LastEvaluatedKey"),
    }


def get_farm_status(farm_id: str) -> dict:
    """Latest reading per device + irrigation state."""
    devices = _list_farm_devices(farm_id)
    status = []

    for device_id in devices:
        pk = f"{farm_id}#{device_id}"
        resp = sensor_table.query(
            KeyConditionExpression=Key("pk").eq(pk),
            ScanIndexForward=False,
            Limit=1,
        )
        latest = resp["Items"][0] if resp["Items"] else None
        status.append({
            "device_id": device_id,
            "latest":    _clean_item(latest) if latest else None,
            "online":    latest is not None,
        })

    config = _get_config(farm_id)
    return {
        "farm_id":   farm_id,
        "devices":   status,
        "threshold": float(config.get("moisture_threshold", 35)),
    }


def update_farm_config(farm_id: str, body: dict) -> dict:
    threshold = body.get("moisture_threshold")
    max_mins  = body.get("max_irrigate_mins")

    updates = {}
    if threshold is not None:
        if not (0 < float(threshold) <= 100):
            raise ValueError("moisture_threshold must be 0–100")
        updates["moisture_threshold"] = Decimal(str(threshold))
    if max_mins is not None:
        updates["max_irrigate_mins"] = int(max_mins)

    if not updates:
        raise ValueError("Nothing to update")

    update_expr = "SET " + ", ".join(f"#{k} = :{k}" for k in updates)
    expr_names  = {f"#{k}": k for k in updates}
    expr_values = {f":{k}": v for k, v in updates.items()}

    farm_table.update_item(
        Key={"farm_id": farm_id},
        UpdateExpression=update_expr,
        ExpressionAttributeNames=expr_names,
        ExpressionAttributeValues=expr_values,
    )
    return {"message": "Config updated", "farm_id": farm_id, "updates": {k: str(v) for k, v in updates.items()}}


def manual_irrigate(farm_id: str, body: dict) -> dict:
    duration = int(body.get("duration_mins", 10))
    if not (1 <= duration <= 60):
        raise ValueError("duration_mins must be 1–60")

    topic   = f"agrisense/{farm_id}/commands"
    command = {
        "action":       "IRRIGATE",
        "duration_min": duration,
        "urgency":      "MANUAL",
        "issued_at":    datetime.utcnow().isoformat() + "Z",
    }
    iot_client.publish(topic=topic, qos=1, payload=json.dumps(command))
    logger.info(f"Manual irrigate sent to {topic}")
    return {"message": f"Manual irrigation started for {duration} minutes", "farm_id": farm_id}


# ──────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────

def _list_farm_devices(farm_id: str) -> list:
    """Return device IDs registered under this farm."""
    resp = farm_table.get_item(Key={"farm_id": farm_id})
    item = resp.get("Item", {})
    return item.get("devices", ["sensor-001"])   # default for demo


def _get_config(farm_id: str) -> dict:
    resp = farm_table.get_item(Key={"farm_id": farm_id})
    return resp.get("Item", {})


def _clean_item(item: dict) -> dict:
    """Convert Decimal → float for JSON serialisation."""
    return {k: (float(v) if isinstance(v, Decimal) else v) for k, v in item.items()}


def build_response(status: int, body: dict, headers: dict) -> dict:
    return {
        "statusCode": status,
        "headers":    headers,
        "body":       json.dumps(body),
    }
