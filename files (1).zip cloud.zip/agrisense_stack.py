"""
AgriSense - AWS CDK Infrastructure Stack (Python)
Provisions all required AWS resources.

Install deps:
  pip install aws-cdk-lib constructs

Deploy:
  cdk bootstrap
  cdk deploy
"""

from aws_cdk import (
    Stack, Duration, RemovalPolicy,
    aws_dynamodb as dynamodb,
    aws_iot as iot,
    aws_lambda as _lambda,
    aws_lambda_event_sources as event_sources,
    aws_apigateway as apigw,
    aws_sns as sns,
    aws_sns_subscriptions as subscriptions,
    aws_iam as iam,
    aws_logs as logs,
)
from constructs import Construct


class AgriSenseStack(Stack):

    def __init__(self, scope: Construct, construct_id: str, **kwargs):
        super().__init__(scope, construct_id, **kwargs)

        # ──────────────────────────────────────────
        # 1. DYNAMODB TABLES
        # ──────────────────────────────────────────

        # Time-series sensor readings
        sensor_table = dynamodb.Table(
            self, "SensorReadings",
            table_name    = "agrisense-sensor-readings",
            partition_key = dynamodb.Attribute(name="pk", type=dynamodb.AttributeType.STRING),
            sort_key      = dynamodb.Attribute(name="sk", type=dynamodb.AttributeType.STRING),
            billing_mode  = dynamodb.BillingMode.PAY_PER_REQUEST,   # auto-scale (on-demand)
            time_to_live_attribute = "ttl",                          # 90-day TTL
            removal_policy = RemovalPolicy.RETAIN,
        )

        # Farm metadata, user config, thresholds
        farm_table = dynamodb.Table(
            self, "FarmConfig",
            table_name    = "agrisense-farm-config",
            partition_key = dynamodb.Attribute(name="farm_id", type=dynamodb.AttributeType.STRING),
            billing_mode  = dynamodb.BillingMode.PAY_PER_REQUEST,
            removal_policy = RemovalPolicy.RETAIN,
        )

        # ──────────────────────────────────────────
        # 2. SNS ALERT TOPIC
        # ──────────────────────────────────────────

        alert_topic = sns.Topic(
            self, "AlertTopic",
            topic_name   = "agrisense-alerts",
            display_name = "AgriSense Farmer Alerts",
        )

        # Add an email/SMS subscription for demo (replace with real number/email)
        alert_topic.add_subscription(
            subscriptions.EmailSubscription("farmer@example.com")
        )

        # ──────────────────────────────────────────
        # 3. SHARED LAMBDA ENV
        # ──────────────────────────────────────────

        shared_env = {
            "SENSOR_TABLE":       sensor_table.table_name,
            "FARM_TABLE":         farm_table.table_name,
            "SNS_ALERT_TOPIC_ARN": alert_topic.topic_arn,
            "IOT_ENDPOINT":       "https://YOUR_IOT_ENDPOINT.amazonaws.com",  # replace
        }

        # ──────────────────────────────────────────
        # 4. INGEST LAMBDA (IoT → DynamoDB)
        # ──────────────────────────────────────────

        ingest_fn = _lambda.Function(
            self, "IngestSensorData",
            function_name  = "agrisense-ingest-sensor-data",
            runtime        = _lambda.Runtime.PYTHON_3_12,
            handler        = "ingest_sensor_data.lambda_handler",
            code           = _lambda.Code.from_asset("lambda"),
            timeout        = Duration.seconds(30),
            memory_size    = 256,
            environment    = shared_env,
            log_retention  = logs.RetentionDays.ONE_MONTH,
        )

        sensor_table.grant_write_data(ingest_fn)
        farm_table.grant_read_data(ingest_fn)
        alert_topic.grant_publish(ingest_fn)
        ingest_fn.add_to_role_policy(iam.PolicyStatement(
            actions   = ["iot:Publish"],
            resources = ["*"],
        ))

        # ──────────────────────────────────────────
        # 5. IoT CORE RULE
        # ──────────────────────────────────────────

        iot_rule_role = iam.Role(
            self, "IoTRuleRole",
            assumed_by = iam.ServicePrincipal("iot.amazonaws.com"),
        )
        ingest_fn.grant_invoke(iot_rule_role)

        iot.CfnTopicRule(
            self, "SensorIngestionRule",
            rule_name            = "agrisense_ingest",
            topic_rule_payload   = iot.CfnTopicRule.TopicRulePayloadProperty(
                sql              = "SELECT * FROM 'agrisense/+/readings'",
                actions          = [
                    iot.CfnTopicRule.ActionProperty(
                        lambda_=iot.CfnTopicRule.LambdaActionProperty(
                            function_arn=ingest_fn.function_arn,
                        )
                    )
                ],
                rule_disabled    = False,
                aws_iot_sql_version = "2016-03-23",
            ),
        )

        # ──────────────────────────────────────────
        # 6. API LAMBDA
        # ──────────────────────────────────────────

        api_fn = _lambda.Function(
            self, "ApiHandler",
            function_name  = "agrisense-api-handler",
            runtime        = _lambda.Runtime.PYTHON_3_12,
            handler        = "api_handler.lambda_handler",
            code           = _lambda.Code.from_asset("lambda"),
            timeout        = Duration.seconds(30),
            memory_size    = 512,
            environment    = shared_env,
            log_retention  = logs.RetentionDays.ONE_MONTH,
        )

        sensor_table.grant_read_data(api_fn)
        farm_table.grant_read_write_data(api_fn)
        api_fn.add_to_role_policy(iam.PolicyStatement(
            actions   = ["iot:Publish"],
            resources = ["*"],
        ))

        # ──────────────────────────────────────────
        # 7. API GATEWAY
        # ──────────────────────────────────────────

        api = apigw.RestApi(
            self, "AgriSenseApi",
            rest_api_name          = "agrisense-api",
            description            = "AgriSense REST API",
            default_cors_preflight_options = apigw.CorsOptions(
                allow_origins = apigw.Cors.ALL_ORIGINS,
                allow_methods = apigw.Cors.ALL_METHODS,
            ),
        )

        integration = apigw.LambdaIntegration(api_fn)

        farms         = api.root.add_resource("farms")
        farm          = farms.add_resource("{farm_id}")
        readings      = farm.add_resource("readings")
        history       = readings.add_resource("history")
        status        = farm.add_resource("status")
        config        = farm.add_resource("config")
        irrigate      = farm.add_resource("irrigate")

        readings.add_method("GET",  integration)
        history.add_method("GET",   integration)
        status.add_method("GET",    integration)
        config.add_method("POST",   integration)
        irrigate.add_method("POST", integration)
