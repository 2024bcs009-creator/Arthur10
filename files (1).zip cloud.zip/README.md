# 🌱 AgriSense — Cloud-Based Precision Irrigation System

> Serverless · Event-Driven · AWS · IoT · React

---

## Project Structure

```
agrisense/
├── lambda/
│   ├── ingest_sensor_data.py   ← IoT data ingestion + irrigation logic
│   └── api_handler.py          ← REST API for dashboard (API Gateway)
│
├── infrastructure/
│   └── agrisense_stack.py      ← AWS CDK (all cloud resources as code)
│
├── device/
│   └── main.py                 ← ESP32 MicroPython firmware
│
├── simulator/
│   └── simulator.py            ← Virtual sensor simulator (100–10,000 devices)
│
├── frontend/
│   └── src/
│       └── App.jsx             ← React dashboard (Recharts + Tailwind)
│
└── tests/
    └── test_agrisense.py       ← Unit + integration tests (pytest + moto)
```

---

## Architecture Overview

```
[ESP32 Sensors] ──MQTT/TLS──► [AWS IoT Core]
                                    │
                              IoT Rule (SQL)
                                    │
                                    ▼
                           [Lambda: ingest_sensor_data]
                           ┌────────────────────────┐
                           │  Validate              │
                           │  Store → DynamoDB      │
                           │  Evaluate moisture     │
                           │  Send command (if dry) │
                           │  Alert farmer (SNS)    │
                           └────────────────────────┘
                                    │
                              ┌─────┴────────┐
                              ▼              ▼
                         [DynamoDB]      [IoT Core]
                    (time-series store)  (commands)
                                             │
                                        [ESP32 Valve]

[React Dashboard] ──HTTPS──► [API Gateway] ──► [Lambda: api_handler]
                                                        │
                                                   [DynamoDB reads]
```

---

## Quick Start

### 1. AWS Infrastructure

```bash
# Install CDK
pip install aws-cdk-lib constructs

# Bootstrap your AWS account (once)
cdk bootstrap aws://ACCOUNT_ID/us-east-1

# Deploy everything
cd infrastructure
cdk deploy
```

### 2. Lambda Functions

```bash
# Package and deploy (CDK does this automatically)
# For manual deploy:
cd lambda
zip -r function.zip ingest_sensor_data.py
aws lambda update-function-code --function-name agrisense-ingest-sensor-data \
  --zip-file fileb://function.zip
```

### 3. ESP32 Device

```bash
# Install ampy to flash files to ESP32
pip install adafruit-ampy

# Upload firmware
ampy --port /dev/ttyUSB0 put device/main.py
ampy --port /dev/ttyUSB0 put certs/

# Connect serial monitor
screen /dev/ttyUSB0 115200
```

### 4. Run Simulator (No Hardware)

```bash
pip install paho-mqtt boto3
python simulator/simulator.py \
  --farm-id farm-abc \
  --devices 100 \
  --interval 10 \
  --endpoint YOUR_IOT_ENDPOINT \
  --boto3
```

### 5. Run Tests

```bash
pip install pytest moto boto3
pytest tests/ -v
```

### 6. Frontend Dashboard

```bash
cd frontend
npx create-react-app . --template cra-template
cp src/App.jsx src/App.jsx   # (already placed)
npm install recharts tailwindcss
REACT_APP_API_URL=https://your-api-gateway-url npm start
```

---

## Environment Variables (Lambda)

| Variable              | Description                         |
|-----------------------|-------------------------------------|
| `SENSOR_TABLE`        | DynamoDB table for sensor readings  |
| `FARM_TABLE`          | DynamoDB table for farm config      |
| `SNS_ALERT_TOPIC_ARN` | SNS topic ARN for farmer alerts     |
| `IOT_ENDPOINT`        | AWS IoT Core HTTPS endpoint URL     |

---

## Key Design Decisions

| Concern              | Choice                        | Reason                                  |
|----------------------|-------------------------------|-----------------------------------------|
| Sensor protocol      | MQTT over TLS (port 8883)     | Low bandwidth, reliable, IoT standard   |
| Time-series storage  | DynamoDB + TTL (90 days)      | Serverless, auto-scaling, on-demand     |
| Irrigation logic     | Deficit-proportional duration | Avoids over/under watering              |
| Scaling              | Serverless Lambda             | 0 → 10,000 sensors with no config      |
| Cost                 | On-demand DynamoDB + Lambda   | Pay per use, near-zero idle cost        |

---

## Evaluation Targets

| Metric          | Target     |
|-----------------|------------|
| End-to-end latency | < 5 seconds |
| Error rate      | < 0.1%     |
| Max throughput  | 10,000 sensors (≈11 msg/s) |
| Data retention  | 90 days (DynamoDB TTL)      |
