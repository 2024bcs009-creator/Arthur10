"""
AgriSense - Test Suite
Covers: validation, irrigation logic, API routing, DynamoDB writes.

Run:
  pip install pytest moto boto3
  pytest tests/ -v
"""

import json
import os
import pytest
import boto3
from moto import mock_dynamodb, mock_sns, mock_iot_data
from decimal import Decimal
from unittest.mock import MagicMock, patch
from datetime import datetime, timezone

# ── Set env vars before importing lambdas ─────────────────────────────────────
os.environ["SENSOR_TABLE"]        = "agrisense-sensor-readings"
os.environ["FARM_TABLE"]          = "agrisense-farm-config"
os.environ["SNS_ALERT_TOPIC_ARN"] = "arn:aws:sns:us-east-1:123456789012:agrisense-alerts"
os.environ["IOT_ENDPOINT"]        = "https://test.iot.us-east-1.amazonaws.com"
os.environ["AWS_DEFAULT_REGION"]  = "us-east-1"
os.environ["AWS_ACCESS_KEY_ID"]   = "testing"
os.environ["AWS_SECRET_ACCESS_KEY"] = "testing"

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lambda"))

from ingest_sensor_data import (
    validate_payload, ValidationError,
    evaluate_irrigation, store_reading, get_farm_config,
)


# ──────────────────────────────────────────────
# FIXTURES
# ──────────────────────────────────────────────

VALID_PAYLOAD = {
    "device_id":    "sensor-001",
    "farm_id":      "farm-abc",
    "timestamp":    1700000000,
    "soil_moisture": 42.5,
    "temperature":   28.3,
    "humidity":      65.1,
}

DEFAULT_CONFIG = {
    "farm_id":             "farm-abc",
    "moisture_threshold":  35.0,
    "max_irrigate_mins":   20,
}


@pytest.fixture
def aws_tables():
    """Create mocked DynamoDB tables."""
    with mock_dynamodb():
        ddb = boto3.resource("dynamodb", region_name="us-east-1")

        sensor_table = ddb.create_table(
            TableName = "agrisense-sensor-readings",
            KeySchema = [
                {"AttributeName": "pk", "KeyType": "HASH"},
                {"AttributeName": "sk", "KeyType": "RANGE"},
            ],
            AttributeDefinitions = [
                {"AttributeName": "pk", "AttributeType": "S"},
                {"AttributeName": "sk", "AttributeType": "S"},
            ],
            BillingMode = "PAY_PER_REQUEST",
        )

        farm_table = ddb.create_table(
            TableName = "agrisense-farm-config",
            KeySchema = [{"AttributeName": "farm_id", "KeyType": "HASH"}],
            AttributeDefinitions = [
                {"AttributeName": "farm_id", "AttributeType": "S"},
            ],
            BillingMode = "PAY_PER_REQUEST",
        )

        # Seed farm config
        farm_table.put_item(Item={
            "farm_id":             "farm-abc",
            "moisture_threshold":  Decimal("35.0"),
            "max_irrigate_mins":   20,
            "devices":             ["sensor-001"],
        })

        yield sensor_table, farm_table


# ──────────────────────────────────────────────
# VALIDATION TESTS
# ──────────────────────────────────────────────

class TestValidation:

    def test_valid_payload_passes(self):
        result = validate_payload(dict(VALID_PAYLOAD))
        assert result["soil_moisture"] == 42.5
        assert "timestamp" in result

    def test_missing_device_id_raises(self):
        p = dict(VALID_PAYLOAD)
        del p["device_id"]
        with pytest.raises(ValidationError, match="device_id"):
            validate_payload(p)

    def test_missing_farm_id_raises(self):
        p = dict(VALID_PAYLOAD)
        del p["farm_id"]
        with pytest.raises(ValidationError, match="farm_id"):
            validate_payload(p)

    def test_moisture_above_100_raises(self):
        p = {**VALID_PAYLOAD, "soil_moisture": 105}
        with pytest.raises(ValidationError, match="soil_moisture"):
            validate_payload(p)

    def test_moisture_below_0_raises(self):
        p = {**VALID_PAYLOAD, "soil_moisture": -1}
        with pytest.raises(ValidationError, match="soil_moisture"):
            validate_payload(p)

    def test_temperature_out_of_range_raises(self):
        p = {**VALID_PAYLOAD, "temperature": 999}
        with pytest.raises(ValidationError, match="temperature"):
            validate_payload(p)

    def test_non_numeric_moisture_raises(self):
        p = {**VALID_PAYLOAD, "soil_moisture": "wet"}
        with pytest.raises(ValidationError):
            validate_payload(p)

    def test_timestamp_auto_filled_when_missing(self):
        p = {k: v for k, v in VALID_PAYLOAD.items() if k != "timestamp"}
        result = validate_payload(p)
        assert isinstance(result["timestamp"], int)
        assert result["timestamp"] > 0

    def test_boundary_moisture_0_valid(self):
        p = {**VALID_PAYLOAD, "soil_moisture": 0}
        result = validate_payload(p)
        assert result["soil_moisture"] == 0

    def test_boundary_moisture_100_valid(self):
        p = {**VALID_PAYLOAD, "soil_moisture": 100}
        result = validate_payload(p)
        assert result["soil_moisture"] == 100


# ──────────────────────────────────────────────
# IRRIGATION LOGIC TESTS
# ──────────────────────────────────────────────

class TestIrrigationDecision:

    def test_dry_soil_triggers_irrigation(self):
        data = {**VALID_PAYLOAD, "soil_moisture": 20.0}
        result = evaluate_irrigation(data, DEFAULT_CONFIG)
        assert result["should_irrigate"] is True

    def test_wet_soil_no_irrigation(self):
        data = {**VALID_PAYLOAD, "soil_moisture": 60.0}
        result = evaluate_irrigation(data, DEFAULT_CONFIG)
        assert result["should_irrigate"] is False

    def test_exactly_at_threshold_no_irrigation(self):
        data = {**VALID_PAYLOAD, "soil_moisture": 35.0}
        result = evaluate_irrigation(data, DEFAULT_CONFIG)
        assert result["should_irrigate"] is False

    def test_just_below_threshold_triggers(self):
        data = {**VALID_PAYLOAD, "soil_moisture": 34.9}
        result = evaluate_irrigation(data, DEFAULT_CONFIG)
        assert result["should_irrigate"] is True

    def test_very_dry_soil_is_high_urgency(self):
        data = {**VALID_PAYLOAD, "soil_moisture": 10.0}
        result = evaluate_irrigation(data, DEFAULT_CONFIG)
        assert result["urgency"] == "HIGH"

    def test_mildly_dry_soil_is_normal_urgency(self):
        data = {**VALID_PAYLOAD, "soil_moisture": 30.0}
        result = evaluate_irrigation(data, DEFAULT_CONFIG)
        assert result["urgency"] == "NORMAL"

    def test_duration_capped_at_max(self):
        data = {**VALID_PAYLOAD, "soil_moisture": 1.0}   # severely dry
        result = evaluate_irrigation(data, DEFAULT_CONFIG)
        assert result["duration_mins"] <= DEFAULT_CONFIG["max_irrigate_mins"]

    def test_duration_zero_when_not_irrigating(self):
        data = {**VALID_PAYLOAD, "soil_moisture": 80.0}
        result = evaluate_irrigation(data, DEFAULT_CONFIG)
        assert result["duration_mins"] == 0

    def test_custom_threshold_respected(self):
        config = {**DEFAULT_CONFIG, "moisture_threshold": 60.0}
        data   = {**VALID_PAYLOAD, "soil_moisture": 55.0}
        result = evaluate_irrigation(data, config)
        assert result["should_irrigate"] is True


# ──────────────────────────────────────────────
# DYNAMODB WRITE TEST
# ──────────────────────────────────────────────

class TestDynamoDBStorage:

    def test_store_reading_writes_to_table(self, aws_tables):
        sensor_table, _ = aws_tables
        data = validate_payload(dict(VALID_PAYLOAD))

        # Patch the module-level table reference
        import ingest_sensor_data as module
        module.sensor_table = sensor_table

        store_reading(data)

        pk = f"{data['farm_id']}#{data['device_id']}"
        resp = sensor_table.query(
            KeyConditionExpression=boto3.dynamodb.conditions.Key("pk").eq(pk),
        )
        assert resp["Count"] == 1
        item = resp["Items"][0]
        assert float(item["soil_moisture"]) == pytest.approx(42.5)
        assert "ttl" in item   # TTL must be set

    def test_store_reading_sets_ttl_90_days(self, aws_tables):
        sensor_table, _ = aws_tables
        data = validate_payload(dict(VALID_PAYLOAD))

        import ingest_sensor_data as module
        module.sensor_table = sensor_table

        store_reading(data)

        pk = f"{data['farm_id']}#{data['device_id']}"
        resp = sensor_table.query(
            KeyConditionExpression=boto3.dynamodb.conditions.Key("pk").eq(pk),
        )
        item = resp["Items"][0]
        expected_ttl = data["timestamp"] + 90 * 24 * 3600
        assert item["ttl"] == expected_ttl


# ──────────────────────────────────────────────
# FARM CONFIG FALLBACK TEST
# ──────────────────────────────────────────────

class TestFarmConfig:

    def test_get_config_returns_defaults_for_unknown_farm(self, aws_tables):
        _, farm_table = aws_tables

        import ingest_sensor_data as module
        module.farm_table = farm_table

        config = get_farm_config("nonexistent-farm")
        assert config["moisture_threshold"] == 35.0
        assert config["max_irrigate_mins"]  == 20

    def test_get_config_returns_stored_config(self, aws_tables):
        _, farm_table = aws_tables

        import ingest_sensor_data as module
        module.farm_table = farm_table

        config = get_farm_config("farm-abc")
        assert float(config["moisture_threshold"]) == 35.0


# ──────────────────────────────────────────────
# END-TO-END (INTEGRATION) TEST
# ──────────────────────────────────────────────

class TestEndToEnd:

    def test_full_pipeline_dry_soil_sends_command(self, aws_tables):
        """
        Dry soil payload → stored in DB → evaluate → command sent to IoT.
        """
        sensor_table, farm_table = aws_tables

        with mock_sns(), mock_iot_data():
            # Setup SNS topic
            sns = boto3.client("sns", region_name="us-east-1")
            topic = sns.create_topic(Name="agrisense-alerts")

            iot = boto3.client("iot-data", endpoint_url="https://test.iot.us-east-1.amazonaws.com",
                               region_name="us-east-1")

            import ingest_sensor_data as module
            module.sensor_table = sensor_table
            module.farm_table   = farm_table
            module.sns_client   = sns
            module.iot_client   = iot
            os.environ["SNS_ALERT_TOPIC_ARN"] = topic["TopicArn"]

            dry_payload = {**VALID_PAYLOAD, "soil_moisture": 15.0}  # Very dry
            result = module.lambda_handler(dry_payload, {})

            assert result["statusCode"] == 200
            assert result["decision"]["should_irrigate"] is True
            assert result["decision"]["urgency"] == "HIGH"

    def test_full_pipeline_wet_soil_no_command(self, aws_tables):
        sensor_table, farm_table = aws_tables

        with mock_sns(), mock_iot_data():
            sns = boto3.client("sns", region_name="us-east-1")
            iot = boto3.client("iot-data", endpoint_url="https://test.iot.us-east-1.amazonaws.com",
                               region_name="us-east-1")

            import ingest_sensor_data as module
            module.sensor_table = sensor_table
            module.farm_table   = farm_table
            module.sns_client   = sns
            module.iot_client   = iot

            wet_payload = {**VALID_PAYLOAD, "soil_moisture": 75.0}
            result = module.lambda_handler(wet_payload, {})

            assert result["statusCode"] == 200
            assert result["decision"]["should_irrigate"] is False
